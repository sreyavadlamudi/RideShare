# Names : Zakari Clark, Sreya Vadlamudi
# Student ID : 2379268, 2371434
# Email : zaclark@chapman.edu, vadlamudi@chapman.edu
# Course : Database Management
# Assignment : Assignment 5 : MySQL RideShare lab
# Resources : Python library
# To run : python3 RideShareApp.py
